EMxxLX_spi_model behavioral model for the Everspin EMxxLX product family. 

Version 1.7, includes all modes (Octal, Quad and SPI) in the BGA package and (Quad and SPI) in the DFN package.

//  Revision History:
//  1.0     2021.07.27      ADO             - Initial release
//  1.5     2024.03.19      ADO             - Various fixes for DS
//  1.6     2024.04.17      ADO             - Fix problem detecting jesd reset vs initialization
//  1.7     2024.04.21      ADO             - Fix DCC for read status and read flag status regs

