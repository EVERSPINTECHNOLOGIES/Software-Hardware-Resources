
//---------------------------------------------------------------------------------
//
//        This confidential and proprietary software may be used only
//     as authorized by a licensing agreement from Everspin Technologies, Inc.
//     In the event of publication, the following notice is applicable:
//
//                    (C) COPYRIGHT 2016 Everspin Technologies, Inc.
//                          ALL RIGHTS RESERVED
//
//        The entire notice above must be reproduced on all authorized copies.
//
//---------------------------------------------------------------------------------
Current Revision: 2.5

make deliverable:
tar -cvzf mckinley_cm_2p5.tar.gz EverspinSLA.txt readme.txt run_sim st_mram_ddr4_model.sv st_mram_ddr4_parameters_1G.vh st_mram_ddr4_tb.sv

extract deliverable:
tar -xvzf mckinley_cm_2p5.tar.gz

Introduction:
The Everspin DDR4 ST-MRAM behavioral model provides a means for customers to verify memory controller
functionality with DDR4 ST-MRAM devices through simulation.

File Descriptions:
readme.txt                      This file
st_mram_ddr4_model.sv           Single device DDR4 ST-MRAM behavioral model
st_mram_ddr4_parameters_1G.vh   Timing parameters, address configuration, and message verbosity level
st_mram_ddr4_tb.sv              Sample testbench using the st_mram_ddr4_model module
run_sim                         C-Shell script that runs the stand alone testbench
EverspinSLA.txt                 Everspin Software License Agreement


Model Configuration:
The model can be configured for x8 or x16 data widths and 800, 1333, 1600, 1866, 2133, 2400 speed bins.
*** NOTE *** At this time only the 1333 and DLL_OFF bins is supported
These options are configured by defining the following macros:
DATA WIDTH:             `define {X8 | X16}
SPEED BIN:              `define {DLL_OFF | BIN800 | BIN1333 | BIN1600 | BIN1866 | BIN2133 | BIN2400}
Silicon Version:        `define {REV_S1 | REV_S2}
Supported Simulators:   NC-Verilog

need to define either X8 or X16
need to define a Bin
if REV_S2 is not defined, the model will default to REV_S1
can define FAST_SIM - will relax the reset and CKE timings for shorter simulation time

// EOF
